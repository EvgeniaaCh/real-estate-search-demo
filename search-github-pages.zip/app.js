const workspace = document.querySelector('.workspace');
const results = document.querySelector('.results');
const step = document.querySelector('.step');
const hit = document.querySelector('.map-hit');
const toggle = document.querySelector('.map-toggle');
const toggleText = document.querySelector('.toggle-text');
const mobileToggle = document.querySelector('.mobile-toggle');
const mobile = matchMedia('(max-width: 700px)');
const modes = ['compact', 'split', 'full'];
let mode = 0;
const sheetHandle = document.querySelector('.sheet-handle');
const mapPanel = document.querySelector('.map');
let sheetDrag = null;
let sheetAnimation = null;

const cards = document.querySelector('.cards');
const listing = document.querySelector('#listing');
const listRow = document.querySelector('#list-row');
const viewToggle = document.querySelector('.view-toggle');
const viewLabel = viewToggle.querySelector('span');
const viewIcon = viewToggle.querySelector('img');
let listSelected = false;

function renderResults() {
  const showList = listSelected && !mobile.matches;
  workspace.dataset.view = showList ? 'list' : 'cards';
  viewToggle.setAttribute('aria-pressed', String(showList));
  viewLabel.textContent = showList ? 'Списком' : 'Карточками';
  viewIcon.src = showList ? 'assets/rowToggle.svg' : 'assets/grid-figma.svg';

  const template = showList ? listRow : listing;
  const fragment = document.createDocumentFragment();
  for (let index = 0; index < 15; index++) fragment.append(template.content.cloneNode(true));
  cards.replaceChildren(fragment);
  results.scrollTop = 0;
}

viewToggle.addEventListener('click', () => {
  listSelected = !listSelected;
  renderResults();
});
renderResults();

const pins = document.querySelector('.pins');
for (const [x, y, price] of [
  [14, 18, '22 млн'], [36, 23, 'от 18 млн'], [58, 6, '20,1 млн'],
  [35, 45, 'от 19,9 млн'], [54, 58, '26,5 млн'], [28, 83, '25 млн'],
  [62, 86, 'от 26,5 млн'], [81, 23, '22 млн'], [91, 60, '28 млн'],
  [12, 88, '25 млн'], [74, 42, '26,5 млн'], [7, 53, '18 млн'],
]) {
  const pin = document.createElement('span');
  pin.style.left = x + '%';
  pin.style.top = y + '%';
  pin.textContent = price;
  pins.append(pin);
}

function setMode(next) {
  mode = next;
  workspace.dataset.mode = modes[mode];
  results.inert = mode === 2 && !mobile.matches;
  delete workspace.dataset.sheet;
  mapPanel.inert = false;
  sheetDrag = null;
  sheetAnimation?.cancel();
  sheetAnimation = null;
  results.style.removeProperty('--sheet-lift');
  results.style.removeProperty('--sheet-progress');
  if (mode === 2 && mobile.matches) results.scrollTop = 0;
  toggleText.textContent = mobile.matches ? 'Список' : ['На карте', 'Свернуть карту', 'Свернуть карту'][mode];
  step.setAttribute('aria-label', ['Развернуть карту', 'Открыть карту на весь экран', 'Показать объявления рядом с картой'][mode]);
  toggle.setAttribute('aria-label', toggleText.textContent);
  toggle.setAttribute('aria-expanded', String(mode > 0));
}

function advance() {
  setMode(mobile.matches ? 2 : mode === 2 ? 1 : mode + 1);
}

step.addEventListener('click', advance);
hit.addEventListener('click', () => {
  advance();
  toggle.focus();
});
toggle.addEventListener('click', () => {
  const previous = mode;
  setMode(mode === 0 ? 1 : 0);
  if (mobile.matches && previous === 2) mobileToggle.focus();
});
mobileToggle.addEventListener('click', () => {
  setMode(2);
  sheetHandle.focus({ preventScroll: true });
});
mobile.addEventListener('change', () => {
  renderResults();
  setMode(mobile.matches && mode === 1 ? 2 : mode);
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && mode > 0) {
    setMode(0);
    (mobile.matches ? mobileToggle : toggle).focus();
  }
});
setMode(0);





const onboarding = document.querySelector('.onboarding');
const launchOnboarding = document.querySelector('.onboarding-launch');
const spotlight = onboarding.querySelector('.onboarding-spotlight');
const hint = onboarding.querySelector('.onboarding-hint');
const hintTitle = hint.querySelector('h2');
const hintDescription = hint.querySelector('p');
const skipOnboarding = hint.querySelector('.onboarding-skip');
const nextOnboarding = hint.querySelector('.onboarding-next');
const onboardingKey = 'search-onboarding-v1-seen';
const firstHint = { title: hintTitle.textContent, description: hintDescription.textContent, action: nextOnboarding.textContent };
let onboardingStep = 0;
let onboardingSeen = false;
try {
  onboardingSeen = localStorage.getItem(onboardingKey) === 'true';
} catch {
  // The tour can still be completed when browser storage is unavailable.
}

function positionOnboarding() {
  if (!onboarding.open) return;

  const target = onboardingStep === 0 ? step : viewToggle;
  const rect = target.getBoundingClientRect();
  const padding = 8;
  const center = rect.top + rect.height / 2;
  spotlight.style.left = (rect.left - padding) + 'px';
  spotlight.style.top = (rect.top - padding) + 'px';
  spotlight.style.width = (rect.width + padding * 2) + 'px';
  spotlight.style.height = (rect.height + padding * 2) + 'px';

  const side = onboardingStep === 0 ? 'left' : 'right';
  hint.dataset.side = side;
  const left = side === 'left' ? rect.left - hint.offsetWidth - 16 : rect.right + 16;
  const top = Math.max(12, Math.min(center - hint.offsetHeight / 2, innerHeight - hint.offsetHeight - 12));
  hint.style.left = Math.max(12, Math.min(left, innerWidth - hint.offsetWidth - 12)) + 'px';
  hint.style.top = top + 'px';
  hint.style.setProperty('--pointer-y', (center - top) + 'px');
}

function showOnboarding(manual = false) {
  if (mobile.matches || (!manual && onboardingSeen) || onboarding.open || mode !== 0) return;
  onboarding.showModal();
  positionOnboarding();
}

function finishOnboarding() {
  onboardingSeen = true;
  try {
    localStorage.setItem(onboardingKey, 'true');
  } catch {
    // Keep the dismissal in memory for this visit.
  }
  onboarding.close();
}

launchOnboarding.addEventListener('click', async () => {
  onboardingStep = 0;
  hintTitle.textContent = firstHint.title;
  hintDescription.textContent = firstHint.description;
  nextOnboarding.textContent = firstHint.action;
  skipOnboarding.hidden = false;

  if (mode !== 0) {
    setMode(0);
    getComputedStyle(workspace).gridTemplateColumns;
    await Promise.allSettled(workspace.getAnimations().map(animation => animation.finished));
  }
  showOnboarding(true);
});

skipOnboarding.addEventListener('click', finishOnboarding);
nextOnboarding.addEventListener('click', () => {
  if (onboardingStep === 0) {
    onboardingStep = 1;
    hintTitle.textContent = 'Разное отображение сниппетов';
    hintDescription.textContent = 'Меняйте вид сниппетов в рельсе';
    skipOnboarding.hidden = true;
    nextOnboarding.textContent = 'Попробовать';
    positionOnboarding();
    return;
  }

  finishOnboarding();
  viewToggle.focus();
});

onboarding.addEventListener('cancel', event => {
  event.preventDefault();
  finishOnboarding();
});
mobile.addEventListener('change', () => {
  if (mobile.matches && onboarding.open) onboarding.close();
  showOnboarding();
});
window.addEventListener('resize', positionOnboarding);
document.fonts.ready.then(positionOnboarding);
showOnboarding();


const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');

function sheetTravel() {
  const peek = parseFloat(getComputedStyle(results).getPropertyValue('--sheet-peek'));
  return Math.max(1, workspace.clientHeight - peek);
}

function setSheetLift(lift) {
  results.style.setProperty('--sheet-lift', lift + 'px');
  results.style.setProperty('--sheet-progress', lift / sheetTravel());
}

async function settleSheet(expand) {
  if (!mobile.matches || mode !== 2 || sheetAnimation || workspace.dataset.sheet === 'expanded') return;

  const lift = parseFloat(results.style.getPropertyValue('--sheet-lift')) || 0;
  const travel = sheetTravel();
  const end = expand ? travel : 0;
  const animation = results.animate([
    { transform: 'translateY(' + (travel - lift) + 'px)', backgroundColor: getComputedStyle(results).backgroundColor },
    { transform: 'translateY(' + (travel - end) + 'px)', backgroundColor: expand ? '#f2f3f4' : '#fff' }
  ], { duration: reducedMotion.matches ? 0 : 260, easing: 'ease-out', fill: 'forwards' });
  sheetAnimation = animation;

  try {
    await animation.finished;
  } catch {
    return;
  }

  setSheetLift(end);
  animation.cancel();
  sheetAnimation = null;
  if (expand) {
    workspace.dataset.sheet = 'expanded';
    mapPanel.inert = true;
    mobileToggle.focus({ preventScroll: true });
  }
}

sheetHandle.addEventListener('pointerdown', event => {
  if (!event.isPrimary || event.button !== 0 || sheetAnimation) return;
  sheetHandle.setPointerCapture(event.pointerId);
  sheetDrag = { id: event.pointerId, startY: event.clientY, startTime: performance.now(), lift: 0 };
});

sheetHandle.addEventListener('pointermove', event => {
  if (sheetDrag?.id !== event.pointerId) return;
  sheetDrag.lift = Math.max(0, Math.min(sheetTravel(), sheetDrag.startY - event.clientY));
  setSheetLift(sheetDrag.lift);
});

sheetHandle.addEventListener('pointerup', event => {
  if (sheetDrag?.id !== event.pointerId) return;
  const { lift, startTime } = sheetDrag;
  sheetDrag = null;
  const flick = lift > 45 && lift / Math.max(1, performance.now() - startTime) > .45;
  settleSheet(lift >= sheetTravel() * .45 || flick || lift < 5);
});

function cancelSheetDrag(event) {
  if (sheetDrag?.id !== event.pointerId) return;
  sheetDrag = null;
  settleSheet(false);
}

sheetHandle.addEventListener('pointercancel', cancelSheetDrag);
sheetHandle.addEventListener('lostpointercapture', cancelSheetDrag);
sheetHandle.addEventListener('click', event => {
  if (event.detail === 0) settleSheet(true);
});




